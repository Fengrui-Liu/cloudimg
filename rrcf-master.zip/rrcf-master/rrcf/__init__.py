from rrcf.rrcf import *
from rrcf.shingle import shingle
import pkg_resources

__version__ = pkg_resources.get_distribution('rrcf').version
